# encoding: utf-8
"""
lmh common tools
@author: lmh
@software: PyCharm
@file: __init__.py.py
@time: 2020/4/13 15:46
"""
from .trans.google import Google
